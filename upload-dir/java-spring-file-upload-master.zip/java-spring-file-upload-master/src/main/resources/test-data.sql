INSERT INTO user
(`firstName`,
`lastName`,
`age`,
`address`)
VALUES
('Morebodi',
'Modise',
12,
'Molepolole, Botswana');
INSERT INTO user
(`firstName`,
`lastName`,
`age`,
`address`)
VALUES
('Rekz',
'Modise',
100,
'Thamaga, Botswana');
INSERT INTO user
(`firstName`,
`lastName`,
`age`,
`address`)
VALUES
('John',
'Aron',
41,
'123 Spring road, Botswana');